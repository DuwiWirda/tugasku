package com.example.minggu_9

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
